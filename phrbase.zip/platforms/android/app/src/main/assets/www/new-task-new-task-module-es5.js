(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["new-task-new-task-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/new-task/new-task.page.html":
    /*!***********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/new-task/new-task.page.html ***!
      \***********************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppNewTaskNewTaskPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"light\">\n    <ion-buttons slot=\"start\">\n      <ion-back-button [routerLink]=\"['/tabs/reports']\" text=\"\" icon=\"arrow-back\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>New Report</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n  <div>\n    <ion-row no-padding>\n      <ion-col size=\"6\" offset=\"3\">\n        <img [src]=\"image\" alt=\"Report goes here\"/>\n      </ion-col>\n    </ion-row>\n    <ion-row no-padding>\n      <ion-col size=\"6\" offset=\"3\">\n        <ion-button fill=\"outline\" expand=\"block\" size=\"small\" (click)=\"getImages()\">Change Picture</ion-button>\n      </ion-col>\n    </ion-row>\n  </div>\n  <form [formGroup]=\"validations_form\" (ngSubmit)=\"onSubmit(validations_form.value)\">\n    <ion-item>\n      <ion-label position=\"floating\" color=\"medium\">Title</ion-label>\n      <ion-input type=\"text\" formControlName=\"title\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"floating\" color=\"medium\">Description</ion-label>\n      <ion-input type=\"text\" formControlName=\"description\"></ion-input>\n    </ion-item>\n    <ion-button color=\"dark\" class=\"submit-btn\" expand=\"block\" type=\"submit\" [disabled]=\"!validations_form.valid\">Create</ion-button>\n  </form>\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/new-task/new-task-routing.module.ts":
    /*!*****************************************************!*\
      !*** ./src/app/new-task/new-task-routing.module.ts ***!
      \*****************************************************/

    /*! exports provided: NewTaskPageRoutingModule */

    /***/
    function srcAppNewTaskNewTaskRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "NewTaskPageRoutingModule", function () {
        return NewTaskPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _new_task_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./new-task.page */
      "./src/app/new-task/new-task.page.ts");

      var routes = [{
        path: '',
        component: _new_task_page__WEBPACK_IMPORTED_MODULE_3__["NewTaskPage"]
      }];

      var NewTaskPageRoutingModule = function NewTaskPageRoutingModule() {
        _classCallCheck(this, NewTaskPageRoutingModule);
      };

      NewTaskPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], NewTaskPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/new-task/new-task.module.ts":
    /*!*********************************************!*\
      !*** ./src/app/new-task/new-task.module.ts ***!
      \*********************************************/

    /*! exports provided: NewTaskPageModule */

    /***/
    function srcAppNewTaskNewTaskModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "NewTaskPageModule", function () {
        return NewTaskPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _new_task_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./new-task-routing.module */
      "./src/app/new-task/new-task-routing.module.ts");
      /* harmony import */


      var _new_task_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./new-task.page */
      "./src/app/new-task/new-task.page.ts");

      var NewTaskPageModule = function NewTaskPageModule() {
        _classCallCheck(this, NewTaskPageModule);
      };

      NewTaskPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _new_task_routing_module__WEBPACK_IMPORTED_MODULE_5__["NewTaskPageRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]],
        providers: [Location],
        declarations: [_new_task_page__WEBPACK_IMPORTED_MODULE_6__["NewTaskPage"]]
      })], NewTaskPageModule);
      /***/
    },

    /***/
    "./src/app/new-task/new-task.page.scss":
    /*!*********************************************!*\
      !*** ./src/app/new-task/new-task.page.scss ***!
      \*********************************************/

    /*! exports provided: default */

    /***/
    function srcAppNewTaskNewTaskPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".submit-btn {\n  margin-top: 40px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbmV3LXRhc2svbmV3LXRhc2sucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBQ0ksZ0JBQUE7QUFDSiIsImZpbGUiOiJzcmMvYXBwL25ldy10YXNrL25ldy10YXNrLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zdWJtaXQtYnRuIHtcbiAgICBtYXJnaW4tdG9wOiA0MHB4O1xuICB9XG4gICJdfQ== */";
      /***/
    },

    /***/
    "./src/app/new-task/new-task.page.ts":
    /*!*******************************************!*\
      !*** ./src/app/new-task/new-task.page.ts ***!
      \*******************************************/

    /*! exports provided: NewTaskPage */

    /***/
    function srcAppNewTaskNewTaskPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "NewTaskPage", function () {
        return NewTaskPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _firebase_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../firebase.service */
      "./src/app/firebase.service.ts");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _ionic_native_image_picker_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/image-picker/ngx */
      "./node_modules/@ionic-native/image-picker/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @ionic-native/ionic-webview/ngx */
      "./node_modules/@ionic-native/ionic-webview/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
      /*! @ionic-native/camera/ngx */
      "./node_modules/@ionic-native/camera/__ivy_ngcc__/ngx/index.js");

      var NewTaskPage = /*#__PURE__*/function () {
        function NewTaskPage(imagePicker, camera, toastCtrl, loadingCtrl, router, formBuilder, firebaseService, webview, alertController) {
          _classCallCheck(this, NewTaskPage);

          this.imagePicker = imagePicker;
          this.camera = camera;
          this.toastCtrl = toastCtrl;
          this.loadingCtrl = loadingCtrl;
          this.router = router;
          this.formBuilder = formBuilder;
          this.firebaseService = firebaseService;
          this.webview = webview;
          this.alertController = alertController;
        }

        _createClass(NewTaskPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.resetFields();
          }
        }, {
          key: "resetFields",
          value: function resetFields() {
            this.image = "./assets/imgs/default_image.jpg";
            this.validations_form = this.formBuilder.group({
              title: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required),
              description: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required)
            });
          }
        }, {
          key: "onSubmit",
          value: function onSubmit(value) {
            var _this = this;

            var data = {
              title: value.title,
              description: value.description,
              image: this.image
            };
            this.firebaseService.createTask(data).then(function (res) {
              _this.router.navigate(["/tabs/reports"]);
            });
          }
        }, {
          key: "getImages",
          value: function getImages() {
            var _this2 = this;

            this.options = {
              // Android only. Max images to be selected, defaults to 15. If this is set to 1, upon
              // selection of a single image, the plugin will return it.
              //maximumImagesCount: 3,
              // max width and height to allow the images to be.  Will keep aspect
              // ratio no matter what.  So if both are 800, the returned image
              // will be at most 800 pixels wide and 800 pixels tall.  If the width is
              // 800 and height 0 the image will be 800 pixels wide if the source
              // is at least that wide.
              width: 200,
              //height: 200,
              // quality of resized image, defaults to 100
              quality: 25,
              // output type, defaults to FILE_URIs.
              // available options are 
              // window.imagePicker.OutputType.FILE_URI (0) or 
              // window.imagePicker.OutputType.BASE64_STRING (1)
              outputType: 1
            };
            this.imageResponse = [];
            this.imagePicker.getPictures(this.options).then(function (results) {
              for (var i = 0; i < results.length; i++) {
                _this2.uploadImageToFirebase(results[i]);
              }
            }, function (err) {
              alert(err);
            });
          }
        }, {
          key: "openImagePicker",
          value: function openImagePicker() {
            var _this3 = this;

            this.imagePicker.hasReadPermission().then(function (result) {
              if (result == false) {
                // no callbacks required as this opens a popup which returns async
                _this3.imagePicker.requestReadPermission();
              } else if (result == true) {
                _this3.imagePicker.getPictures({
                  maximumImagesCount: 1
                }).then(function (results) {
                  for (var i = 0; i < results.length; i++) {
                    _this3.uploadImageToFirebase(results[i]);
                  }
                }, function (err) {
                  return console.log(err);
                });
              }
            }, function (err) {
              console.log(err);
            });
          }
        }, {
          key: "uploadImageToFirebase",
          value: function uploadImageToFirebase(image) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this4 = this;

              var loading, toast, image_src, randomId;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.loadingCtrl.create({
                        message: 'Please wait...'
                      });

                    case 2:
                      loading = _context.sent;
                      _context.next = 5;
                      return this.toastCtrl.create({
                        message: 'Image was updated successfully',
                        duration: 3000
                      });

                    case 5:
                      toast = _context.sent;
                      this.presentLoading(loading);
                      image_src = this.webview.convertFileSrc(image);
                      randomId = Math.random().toString(36).substr(2, 5); //uploads img to firebase storage

                      this.firebaseService.uploadImage(image_src, randomId).then(function (photoURL) {
                        _this4.image = photoURL;
                        loading.dismiss();
                        toast.present();
                      }, function (err) {
                        console.log(err);
                      });

                    case 10:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "presentLoading",
          value: function presentLoading(loading) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return loading.present();

                    case 2:
                      return _context2.abrupt("return", _context2.sent);

                    case 3:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2);
            }));
          }
        }]);

        return NewTaskPage;
      }();

      NewTaskPage.ctorParameters = function () {
        return [{
          type: _ionic_native_image_picker_ngx__WEBPACK_IMPORTED_MODULE_6__["ImagePicker"]
        }, {
          type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_8__["Camera"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
        }, {
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]
        }, {
          type: _firebase_service__WEBPACK_IMPORTED_MODULE_2__["FirebaseService"]
        }, {
          type: _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_7__["WebView"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
        }];
      };

      NewTaskPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-new-task',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./new-task.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/new-task/new-task.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./new-task.page.scss */
        "./src/app/new-task/new-task.page.scss"))["default"]]
      })], NewTaskPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=new-task-new-task-module-es5.js.map