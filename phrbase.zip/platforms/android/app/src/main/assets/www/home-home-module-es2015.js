(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
/*!***************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
  \***************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n\n<ion-header>\n  <ion-toolbar color=\"primary\">\n    <ion-title>\n      Home\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n<ion-content class=\"ion-padding-top ion-padding-bottom\">\n  <ion-item>\n    <h5 class=\"headingSection\"> Select any one feature to be applied:</h5>\n  </ion-item>\n  <ion-radio-group (ionChange)=\"radioGroupChange($event)\" [value]=\"selectedfeature\">\n    <ion-item>\n      <ion-label>Object Detection</ion-label>\n      <ion-radio value=\"OBJECT_LOCALIZATION\"></ion-radio>\n    </ion-item>\n    <ion-item>\n      <ion-label>Web Detection</ion-label>\n      <ion-radio value=\"WEB_DETECTION\"></ion-radio>\n    </ion-item>\n    <ion-item>\n      <ion-label>Landmark Detection</ion-label>\n      <ion-radio value=\"LANDMARK_DETECTION\"></ion-radio>\n    </ion-item>\n    <ion-item>\n      <ion-label>Label Detection</ion-label>\n      <ion-radio value=\"LABEL_DETECTION\"></ion-radio>\n    </ion-item>\n    <ion-item>\n      <ion-label>Text Detection</ion-label>\n      <ion-radio value=\"TEXT_DETECTION\"></ion-radio>\n    </ion-item>\n    <ion-item>\n      <ion-label>Logo Detection</ion-label>\n      <ion-radio value=\"LOGO_DETECTION\"></ion-radio>\n    </ion-item>\n    <ion-item>\n      <ion-label>Face Detection</ion-label>\n      <ion-radio value=\"FACE_DETECTION\"></ion-radio>\n    </ion-item>\n    <ion-item>\n      <ion-label>Safe Search Detection</ion-label>\n      <ion-radio value=\"SAFE_SEARCH_DETECTION\"></ion-radio>\n    </ion-item>\n    <ion-item>\n      <ion-label>Image Properties</ion-label>\n      <ion-radio value=\"IMAGE_PROPERTIES\"></ion-radio>\n    </ion-item>\n    <ion-item>\n      <ion-label>Crop Hints</ion-label>\n      <ion-radio value=\"CROP_HINTS\"></ion-radio>\n    </ion-item>\n    <ion-item>\n      <ion-label>Document Text Detection</ion-label>\n      <ion-radio value=\"DOCUMENT_TEXT_DETECTION\"></ion-radio>\n    </ion-item>\n  </ion-radio-group>\n  <ion-fab vertical=\"bottom\" horizontal=\"center\" slot=\"fixed\">\n    <ion-fab-button (click)=\"presentAlertConfirm()\">\n      <ion-icon name=\"camera\">\n      </ion-icon>\n    </ion-fab-button>\n  </ion-fab>\n</ion-content>\n<!--  -lc -->");

/***/ }),

/***/ "./src/app/google-cloud-vision-service.service.ts":
/*!********************************************************!*\
  !*** ./src/app/google-cloud-vision-service.service.ts ***!
  \********************************************************/
/*! exports provided: GoogleCloudVisionServiceService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GoogleCloudVisionServiceService", function() { return GoogleCloudVisionServiceService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../environments/environment */ "./src/environments/environment.ts");




let GoogleCloudVisionServiceService = class GoogleCloudVisionServiceService {
    constructor(http) {
        this.http = http;
    }
    getLabels(base64Image, feature) {
        const body = {
            requests: [
                {
                    features: [
                        {
                            type: feature,
                            maxResults: 10
                        }
                    ],
                    image: {
                        content: base64Image
                    }
                }
            ]
        };
        return this.http.post('https://vision.googleapis.com/v1/images:annotate?key=' + _environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].googleCloudVisionAPIKey, body);
    }
};
GoogleCloudVisionServiceService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
GoogleCloudVisionServiceService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], GoogleCloudVisionServiceService);



/***/ }),

/***/ "./src/app/home/home.module.ts":
/*!*************************************!*\
  !*** ./src/app/home/home.module.ts ***!
  \*************************************/
/*! exports provided: HomePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePageModule", function() { return HomePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./home.page */ "./src/app/home/home.page.ts");







let HomePageModule = class HomePageModule {
};
HomePageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([
                {
                    path: '',
                    component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
                }
            ])
        ],
        declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
    })
], HomePageModule);



/***/ }),

/***/ "./src/app/home/home.page.scss":
/*!*************************************!*\
  !*** ./src/app/home/home.page.scss ***!
  \*************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("ion-content,\nion-item {\n  --background: #f0efef;\n}\n\n.headingSection {\n  text-align: center;\n  width: 100%;\n  font-weight: bold;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9ob21lLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQTs7RUFFSSxxQkFBQTtBQUFKOztBQUVBO0VBQ0ksa0JBQUE7RUFDQSxXQUFBO0VBQ0EsaUJBQUE7QUFDSiIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJcbmlvbi1jb250ZW50LFxuaW9uLWl0ZW0ge1xuICAgIC0tYmFja2dyb3VuZDogI2YwZWZlZjtcbn1cbi5oZWFkaW5nU2VjdGlvbiB7XG4gICAgdGV4dC1hbGlnbjogY2VudGVyO1xuICAgIHdpZHRoOiAxMDAlO1xuICAgIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuIl19 */");

/***/ }),

/***/ "./src/app/home/home.page.ts":
/*!***********************************!*\
  !*** ./src/app/home/home.page.ts ***!
  \***********************************/
/*! exports provided: HomePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "HomePage", function() { return HomePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/camera/ngx */ "./node_modules/@ionic-native/camera/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _google_cloud_vision_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../google-cloud-vision-service.service */ "./src/app/google-cloud-vision-service.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");







let HomePage = class HomePage {
    constructor(camera, route, vision, loadingController, alertController) {
        this.camera = camera;
        this.route = route;
        this.vision = vision;
        this.loadingController = loadingController;
        this.alertController = alertController;
        this.selectedfeature = 'OBJECT_LOCALIZATION';
    }
    radioGroupChange(event) {
        this.selectedfeature = event.detail.value;
    }
    selectPhoto() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const options = {
                quality: 100,
                destinationType: this.camera.DestinationType.DATA_URL,
                encodingType: this.camera.EncodingType.JPEG,
                mediaType: this.camera.MediaType.PICTURE,
                sourceType: this.camera.PictureSourceType.SAVEDPHOTOALBUM
            };
            this.camera.getPicture(options).then((imageData) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                // imageData is either a base64 encoded string or a file URI
                // If it's base64:
                const loading = yield this.loadingController.create({
                    message: 'Getting Results...',
                    translucent: true
                });
                yield loading.present();
                this.vision.getLabels(imageData, this.selectedfeature).subscribe((result) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    console.log(result);
                    const navigationExtras = {
                        queryParams: {
                            special: JSON.stringify(imageData),
                            result: JSON.stringify(result),
                            feature: JSON.stringify(this.selectedfeature)
                        }
                    };
                    this.route.navigate(['showclass'], navigationExtras);
                    yield loading.dismiss();
                }), (err) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    console.log(err);
                    yield loading.dismiss();
                }));
            }), (err) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                console.log(err);
            }));
        });
    }
    presentAlertConfirm() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertController.create({
                header: 'Select one option ',
                message: 'Take Photo or Select from Gallery!!!',
                buttons: [
                    {
                        text: 'Camera',
                        role: 'camera',
                        handler: () => {
                            this.takePhoto();
                        }
                    }, {
                        text: 'Gallery',
                        role: 'gallery',
                        handler: () => {
                            this.selectPhoto();
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    takePhoto() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const options = {
                quality: 100,
                targetHeight: 500,
                targetWidth: 500,
                destinationType: this.camera.DestinationType.DATA_URL,
                encodingType: this.camera.EncodingType.JPEG,
                mediaType: this.camera.MediaType.PICTURE,
            };
            this.camera.getPicture(options).then((imageData) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                const loading = yield this.loadingController.create({
                    message: 'Getting Results...',
                    translucent: true
                });
                yield loading.present();
                this.vision.getLabels(imageData, this.selectedfeature).subscribe((result) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    console.log(result);
                    const navigationExtras = {
                        queryParams: {
                            special: JSON.stringify(imageData),
                            result: JSON.stringify(result),
                            feature: JSON.stringify(this.selectedfeature)
                        }
                    };
                    this.route.navigate(['showclass'], navigationExtras);
                    yield loading.dismiss();
                }), (err) => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
                    yield loading.dismiss();
                }));
            }), err => {
                console.log(err);
            });
        });
    }
};
HomePage.ctorParameters = () => [
    { type: _ionic_native_camera_ngx__WEBPACK_IMPORTED_MODULE_2__["Camera"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _google_cloud_vision_service_service__WEBPACK_IMPORTED_MODULE_3__["GoogleCloudVisionServiceService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] }
];
HomePage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-home',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./home.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./home.page.scss */ "./src/app/home/home.page.scss")).default]
    })
], HomePage);



/***/ })

}]);
//# sourceMappingURL=home-home-module-es2015.js.map