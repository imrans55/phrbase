(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["details-details-module"], {
    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/details/details.page.html":
    /*!*********************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/details/details.page.html ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppDetailsDetailsPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar color=\"light\">\n    <ion-buttons slot=\"start\">\n      \n      <ion-back-button [routerLink]=\"['/tabs/reports']\" text=\"\" icon=\"arrow-back\"></ion-back-button>\n    </ion-buttons>\n    <ion-title>Details</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content padding>\n  <div>\n    <ion-row>\n      <ion-col size=\"6\" offset=\"3\">\n        <img [src]=\"image\" alt=\"Repots Goes Here\"/>\n      </ion-col>\n    </ion-row>\n    <ion-row>\n      <ion-col size=\"6\" offset=\"3\">\n        <ion-button fill=\"outline\" expand=\"block\" size=\"small\" (click)=\"openImagePicker()\">Change Picture</ion-button>\n      </ion-col>\n    </ion-row>\n  </div>\n  <form [formGroup]=\"validations_form\" (ngSubmit)=\"onSubmit(validations_form.value)\">\n    <ion-item>\n      <ion-label position=\"floating\" color=\"primary\">Title</ion-label>\n      <ion-input type=\"text\" formControlName=\"title\"></ion-input>\n    </ion-item>\n    <ion-item>\n      <ion-label position=\"floating\" color=\"primary\">Description</ion-label>\n      <ion-input type=\"text\" formControlName=\"description\"></ion-input>\n    </ion-item>\n    <ion-button color=\"medium\" class=\"submit-button\" expand=\"block\" type=\"submit\" [disabled]=\"!validations_form.valid\">Save</ion-button>\n  </form>\n  <ion-button color=\"dark\" class=\"delete-button\" expand=\"block\" color=\"danger\" (click)=\"delete()\">Delete</ion-button>\n\n</ion-content>\n";
      /***/
    },

    /***/
    "./src/app/details/details-routing.module.ts":
    /*!***************************************************!*\
      !*** ./src/app/details/details-routing.module.ts ***!
      \***************************************************/

    /*! exports provided: DetailsPageRoutingModule */

    /***/
    function srcAppDetailsDetailsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DetailsPageRoutingModule", function () {
        return DetailsPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./details.page */
      "./src/app/details/details.page.ts");
      /* harmony import */


      var _details_resolver__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ./details.resolver */
      "./src/app/details/details.resolver.ts");

      var routes = [{
        path: ':id',
        component: _details_page__WEBPACK_IMPORTED_MODULE_3__["DetailsPage"],
        resolve: {
          data: _details_resolver__WEBPACK_IMPORTED_MODULE_4__["DetailsResolver"]
        }
      }];

      var DetailsPageRoutingModule = function DetailsPageRoutingModule() {
        _classCallCheck(this, DetailsPageRoutingModule);
      };

      DetailsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
        providers: [_details_resolver__WEBPACK_IMPORTED_MODULE_4__["DetailsResolver"]]
      })], DetailsPageRoutingModule);
      /***/
    },

    /***/
    "./src/app/details/details.module.ts":
    /*!*******************************************!*\
      !*** ./src/app/details/details.module.ts ***!
      \*******************************************/

    /*! exports provided: DetailsPageModule */

    /***/
    function srcAppDetailsDetailsModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DetailsPageModule", function () {
        return DetailsPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _details_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./details.page */
      "./src/app/details/details.page.ts");
      /* harmony import */


      var _details_resolver__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./details.resolver */
      "./src/app/details/details.resolver.ts");
      /* harmony import */


      var _details_routing_module__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! ./details-routing.module */
      "./src/app/details/details-routing.module.ts");

      var DetailsPageModule = function DetailsPageModule() {
        _classCallCheck(this, DetailsPageModule);
      };

      DetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"], _details_routing_module__WEBPACK_IMPORTED_MODULE_7__["DetailsPageRoutingModule"]],
        declarations: [_details_page__WEBPACK_IMPORTED_MODULE_5__["DetailsPage"]],
        providers: [_details_resolver__WEBPACK_IMPORTED_MODULE_6__["DetailsResolver"]]
      })], DetailsPageModule);
      /***/
    },

    /***/
    "./src/app/details/details.page.scss":
    /*!*******************************************!*\
      !*** ./src/app/details/details.page.scss ***!
      \*******************************************/

    /*! exports provided: default */

    /***/
    function srcAppDetailsDetailsPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = ".submit-button {\n  margin-top: 40px;\n}\n\n.delete-button {\n  margin-top: 20px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGV0YWlscy9kZXRhaWxzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNJLGdCQUFBO0FBQ0o7O0FBQ0U7RUFDRyxnQkFBQTtBQUVMIiwiZmlsZSI6InNyYy9hcHAvZGV0YWlscy9kZXRhaWxzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zdWJtaXQtYnV0dG9uIHtcbiAgICBtYXJnaW4tdG9wOiA0MHB4O1xuICB9XG4gIC5kZWxldGUtYnV0dG9uIHtcbiAgICAgbWFyZ2luLXRvcDogMjBweDtcbiAgfSJdfQ== */";
      /***/
    },

    /***/
    "./src/app/details/details.page.ts":
    /*!*****************************************!*\
      !*** ./src/app/details/details.page.ts ***!
      \*****************************************/

    /*! exports provided: DetailsPage */

    /***/
    function srcAppDetailsDetailsPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DetailsPage", function () {
        return DetailsPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _firebase_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../firebase.service */
      "./src/app/firebase.service.ts");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _ionic_native_image_picker_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic-native/image-picker/ngx */
      "./node_modules/@ionic-native/image-picker/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! @ionic-native/ionic-webview/ngx */
      "./node_modules/@ionic-native/ionic-webview/__ivy_ngcc__/ngx/index.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

      var DetailsPage = /*#__PURE__*/function () {
        function DetailsPage(imagePicker, toastCtrl, loadingCtrl, formBuilder, firebaseService, webview, alertCtrl, route, router) {
          _classCallCheck(this, DetailsPage);

          this.imagePicker = imagePicker;
          this.toastCtrl = toastCtrl;
          this.loadingCtrl = loadingCtrl;
          this.formBuilder = formBuilder;
          this.firebaseService = firebaseService;
          this.webview = webview;
          this.alertCtrl = alertCtrl;
          this.route = route;
          this.router = router;
          this.load = false;
        }

        _createClass(DetailsPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            this.getData();
          }
        }, {
          key: "getData",
          value: function getData() {
            var _this = this;

            this.route.data.subscribe(function (routeData) {
              var data = routeData['data'];

              if (data) {
                _this.item = data;
                _this.image = _this.item.image;
              }
            });
            this.validations_form = this.formBuilder.group({
              title: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"](this.item.title, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required),
              description: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"](this.item.description, _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required)
            });
          }
        }, {
          key: "onSubmit",
          value: function onSubmit(value) {
            var _this2 = this;

            var data = {
              title: value.title,
              description: value.description,
              image: this.image
            };
            this.firebaseService.updateTask(this.item.id, data).then(function (res) {
              _this2.router.navigate(["/tabs/reports"]);
            });
          }
        }, {
          key: "delete",
          value: function _delete() {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              var _this3 = this;

              var alert;
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.alertCtrl.create({
                        header: 'Confirm',
                        message: 'Do you want to delete ' + this.item.title + '?',
                        buttons: [{
                          text: 'No',
                          role: 'cancel',
                          cssClass: 'secondary',
                          handler: function handler() {}
                        }, {
                          text: 'Yes',
                          handler: function handler() {
                            _this3.firebaseService.deleteTask(_this3.item.id).then(function (res) {
                              _this3.router.navigate(["/tabs/reports"]);
                            }, function (err) {
                              return console.log(err);
                            });
                          }
                        }]
                      });

                    case 2:
                      alert = _context.sent;
                      _context.next = 5;
                      return alert.present();

                    case 5:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          }
        }, {
          key: "openImagePicker",
          value: function openImagePicker() {
            var _this4 = this;

            this.imagePicker.hasReadPermission().then(function (result) {
              if (result == false) {
                // no callbacks required as this opens a popup which returns async
                _this4.imagePicker.requestReadPermission();
              } else if (result == true) {
                _this4.imagePicker.getPictures({
                  maximumImagesCount: 1
                }).then(function (results) {
                  for (var i = 0; i < results.length; i++) {
                    _this4.uploadImageToFirebase(results[i]);
                  }
                }, function (err) {
                  return console.log(err);
                });
              }
            }, function (err) {
              console.log(err);
            });
          }
        }, {
          key: "uploadImageToFirebase",
          value: function uploadImageToFirebase(image) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              var _this5 = this;

              var loading, toast, image_src, randomId;
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.loadingCtrl.create({
                        message: 'Please wait...'
                      });

                    case 2:
                      loading = _context2.sent;
                      _context2.next = 5;
                      return this.toastCtrl.create({
                        message: 'Image was updated successfully',
                        duration: 3000
                      });

                    case 5:
                      toast = _context2.sent;
                      this.presentLoading(loading); // let image_to_convert = 'http://localhost:8080/_file_' + image;

                      image_src = this.webview.convertFileSrc(image);
                      randomId = Math.random().toString(36).substr(2, 5); //uploads img to firebase storage

                      this.firebaseService.uploadImage(image_src, randomId).then(function (photoURL) {
                        _this5.image = photoURL;
                        loading.dismiss();
                        toast.present();
                      }, function (err) {
                        console.log(err);
                      });

                    case 10:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          }
        }, {
          key: "presentLoading",
          value: function presentLoading(loading) {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return loading.present();

                    case 2:
                      return _context3.abrupt("return", _context3.sent);

                    case 3:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3);
            }));
          }
        }]);

        return DetailsPage;
      }();

      DetailsPage.ctorParameters = function () {
        return [{
          type: _ionic_native_image_picker_ngx__WEBPACK_IMPORTED_MODULE_5__["ImagePicker"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
        }, {
          type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]
        }, {
          type: _firebase_service__WEBPACK_IMPORTED_MODULE_2__["FirebaseService"]
        }, {
          type: _ionic_native_ionic_webview_ngx__WEBPACK_IMPORTED_MODULE_6__["WebView"]
        }, {
          type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["ActivatedRoute"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"]
        }];
      };

      DetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-details',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./details.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/details/details.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./details.page.scss */
        "./src/app/details/details.page.scss"))["default"]]
      })], DetailsPage);
      /***/
    },

    /***/
    "./src/app/details/details.resolver.ts":
    /*!*********************************************!*\
      !*** ./src/app/details/details.resolver.ts ***!
      \*********************************************/

    /*! exports provided: DetailsResolver */

    /***/
    function srcAppDetailsDetailsResolverTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "DetailsResolver", function () {
        return DetailsResolver;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _firebase_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ../firebase.service */
      "./src/app/firebase.service.ts");

      var DetailsResolver = /*#__PURE__*/function () {
        function DetailsResolver(firebaseService) {
          _classCallCheck(this, DetailsResolver);

          this.firebaseService = firebaseService;
        }

        _createClass(DetailsResolver, [{
          key: "resolve",
          value: function resolve(route) {
            var _this6 = this;

            return new Promise(function (resolve, reject) {
              var itemId = route.paramMap.get('id');

              _this6.firebaseService.getTask(itemId).then(function (data) {
                data.id = itemId;
                resolve(data);
              }, function (err) {
                reject(err);
              });
            });
          }
        }]);

        return DetailsResolver;
      }();

      DetailsResolver.ctorParameters = function () {
        return [{
          type: _firebase_service__WEBPACK_IMPORTED_MODULE_2__["FirebaseService"]
        }];
      };

      DetailsResolver = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])()], DetailsResolver);
      /***/
    }
  }]);
})();
//# sourceMappingURL=details-details-module-es5.js.map