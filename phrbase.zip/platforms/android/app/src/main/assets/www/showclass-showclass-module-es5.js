(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

  function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

  function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

  function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

  function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

  function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["showclass-showclass-module"], {
    /***/
    "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-functions.js":
    /*!************************************************************************************!*\
      !*** ./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-functions.js ***!
      \************************************************************************************/

    /*! exports provided: AngularFireFunctions, AngularFireFunctionsModule, NEW_ORIGIN_BEHAVIOR, ORIGIN, REGION, USE_EMULATOR */

    /***/
    function node_modulesAngularFire__ivy_ngcc__Fesm2015AngularFireFunctionsJs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AngularFireFunctions", function () {
        return AngularFireFunctions;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "AngularFireFunctionsModule", function () {
        return AngularFireFunctionsModule;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "NEW_ORIGIN_BEHAVIOR", function () {
        return NEW_ORIGIN_BEHAVIOR;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ORIGIN", function () {
        return ORIGIN;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "REGION", function () {
        return REGION;
      });
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "USE_EMULATOR", function () {
        return USE_EMULATOR;
      });
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var rxjs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! rxjs */
      "./node_modules/rxjs/_esm2015/index.js");
      /* harmony import */


      var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! rxjs/operators */
      "./node_modules/rxjs/_esm2015/operators/index.js");
      /* harmony import */


      var _angular_fire__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/fire */
      "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire.js");
      /**
       * @fileoverview added by tsickle
       * Generated from: base.ts
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */

      /** @type {?} */


      var proxyPolyfillCompat = {
        useEmulator: null,
        useFunctionsEmulator: null,
        httpsCallable: null
      };
      /**
       * @fileoverview added by tsickle
       * Generated from: functions.ts
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */

      /** @type {?} */

      var ORIGIN = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["InjectionToken"]('angularfire2.functions.origin');
      /** @type {?} */

      var REGION = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["InjectionToken"]('angularfire2.functions.region');
      /** @type {?} */

      var NEW_ORIGIN_BEHAVIOR = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["InjectionToken"]('angularfire2.functions.new-origin-behavior');
      /** @type {?} */

      var USE_EMULATOR = new _angular_core__WEBPACK_IMPORTED_MODULE_0__["InjectionToken"]('angularfire2.functions.use-emulator'); // WARNING: interface has both a type and a value, skipping emit

      var AngularFireFunctions =
      /**
       * @param {?} options
       * @param {?} nameOrConfig
       * @param {?} zone
       * @param {?} region
       * @param {?} origin
       * @param {?} newOriginBehavior
       * @param {?} _useEmulator
       */
      function AngularFireFunctions(options, nameOrConfig, zone, region, origin, newOriginBehavior, _useEmulator) {
        _classCallCheck(this, AngularFireFunctions);

        /** @type {?} */
        var schedulers = new _angular_fire__WEBPACK_IMPORTED_MODULE_3__["ɵAngularFireSchedulers"](zone);
        /** @type {?} */

        var useEmulator = _useEmulator;
        /** @type {?} */

        var functions = Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["of"])(undefined).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["observeOn"])(schedulers.outsideAngular), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["switchMap"])(
        /**
        * @return {?}
        */
        function () {
          return __webpack_require__.e(
          /*! import() | firebase-functions */
          "firebase-functions").then(__webpack_require__.bind(null,
          /*! firebase/functions */
          "./node_modules/firebase/functions/dist/index.esm.js"));
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(
        /**
        * @return {?}
        */
        function () {
          return Object(_angular_fire__WEBPACK_IMPORTED_MODULE_3__["ɵfirebaseAppFactory"])(options, zone, nameOrConfig);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(
        /**
        * @param {?} app
        * @return {?}
        */
        function (app) {
          return Object(_angular_fire__WEBPACK_IMPORTED_MODULE_3__["ɵfetchInstance"])("".concat(app.name, ".functions.").concat(region || origin), 'AngularFireFunctions', app,
          /**
          * @return {?}
          */
          function () {
            /** @type {?} */
            var functions;

            if (newOriginBehavior) {
              if (region && origin) {
                throw new Error('REGION and ORIGIN can\'t be used at the same time.');
              }

              functions = app.functions(region || origin || undefined);
            } else {
              functions = app.functions(region || undefined);
            }

            if (!newOriginBehavior && !useEmulator && origin) {
              functions.useFunctionsEmulator(origin);
            }

            if (useEmulator) {
              var _functions;

              (_functions = functions).useEmulator.apply(_functions, _toConsumableArray(useEmulator));
            }

            return functions;
          }, [region, origin, useEmulator]);
        }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["shareReplay"])({
          bufferSize: 1,
          refCount: false
        }));

        this.httpsCallable =
        /**
        * @template T, R
        * @param {?} name
        * @param {?=} options
        * @return {?}
        */
        function (name, options) {
          return (
            /**
            * @param {?} data
            * @return {?}
            */
            function (data) {
              return Object(rxjs__WEBPACK_IMPORTED_MODULE_1__["from"])(functions).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["observeOn"])(schedulers.insideAngular), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["switchMap"])(
              /**
              * @param {?} functions
              * @return {?}
              */
              function (functions) {
                return functions.httpsCallable(name, options)(data);
              }), Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["map"])(
              /**
              * @param {?} r
              * @return {?}
              */
              function (r) {
                return (
                  /** @type {?} */
                  r.data
                );
              }));
            }
          );
        };

        return Object(_angular_fire__WEBPACK_IMPORTED_MODULE_3__["ɵlazySDKProxy"])(this, functions, zone);
      };

      AngularFireFunctions.ɵfac = function AngularFireFunctions_Factory(t) {
        return new (t || AngularFireFunctions)(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_fire__WEBPACK_IMPORTED_MODULE_3__["FIREBASE_OPTIONS"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_fire__WEBPACK_IMPORTED_MODULE_3__["FIREBASE_APP_NAME"], 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](REGION, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](ORIGIN, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](NEW_ORIGIN_BEHAVIOR, 8), _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"](USE_EMULATOR, 8));
      };
      /** @nocollapse */


      AngularFireFunctions.ctorParameters = function () {
        return [{
          type: undefined,
          decorators: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
            args: [_angular_fire__WEBPACK_IMPORTED_MODULE_3__["FIREBASE_OPTIONS"]]
          }]
        }, {
          type: undefined,
          decorators: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
          }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
            args: [_angular_fire__WEBPACK_IMPORTED_MODULE_3__["FIREBASE_APP_NAME"]]
          }]
        }, {
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]
        }, {
          type: undefined,
          decorators: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
          }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
            args: [REGION]
          }]
        }, {
          type: undefined,
          decorators: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
          }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
            args: [ORIGIN]
          }]
        }, {
          type: undefined,
          decorators: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
          }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
            args: [NEW_ORIGIN_BEHAVIOR]
          }]
        }, {
          type: undefined,
          decorators: [{
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
          }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
            args: [USE_EMULATOR]
          }]
        }];
      };
      /** @nocollapse */


      AngularFireFunctions.ɵprov = Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjectable"])({
        factory: function AngularFireFunctions_Factory() {
          return new AngularFireFunctions(Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"])(_angular_fire__WEBPACK_IMPORTED_MODULE_3__["FIREBASE_OPTIONS"]), Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"])(_angular_fire__WEBPACK_IMPORTED_MODULE_3__["FIREBASE_APP_NAME"], 8), Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"])(_angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]), Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"])(REGION, 8), Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"])(ORIGIN, 8), Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"])(NEW_ORIGIN_BEHAVIOR, 8), Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵinject"])(USE_EMULATOR, 8));
        },
        token: AngularFireFunctions,
        providedIn: "any"
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AngularFireFunctions, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Injectable"],
          args: [{
            providedIn: 'any'
          }]
        }], function () {
          return [{
            type: undefined,
            decorators: [{
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
              args: [_angular_fire__WEBPACK_IMPORTED_MODULE_3__["FIREBASE_OPTIONS"]]
            }]
          }, {
            type: undefined,
            decorators: [{
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }, {
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
              args: [_angular_fire__WEBPACK_IMPORTED_MODULE_3__["FIREBASE_APP_NAME"]]
            }]
          }, {
            type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgZone"]
          }, {
            type: undefined,
            decorators: [{
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }, {
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
              args: [REGION]
            }]
          }, {
            type: undefined,
            decorators: [{
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }, {
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
              args: [ORIGIN]
            }]
          }, {
            type: undefined,
            decorators: [{
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }, {
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
              args: [NEW_ORIGIN_BEHAVIOR]
            }]
          }, {
            type: undefined,
            decorators: [{
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Optional"]
            }, {
              type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["Inject"],
              args: [USE_EMULATOR]
            }]
          }];
        }, null);
      })();

      if (false) {}

      Object(_angular_fire__WEBPACK_IMPORTED_MODULE_3__["ɵapplyMixins"])(AngularFireFunctions, [proxyPolyfillCompat]);
      /**
       * @fileoverview added by tsickle
       * Generated from: functions.module.ts
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */

      var AngularFireFunctionsModule = function AngularFireFunctionsModule() {
        _classCallCheck(this, AngularFireFunctionsModule);
      };

      AngularFireFunctionsModule.ɵmod = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineNgModule"]({
        type: AngularFireFunctionsModule
      });
      AngularFireFunctionsModule.ɵinj = _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵɵdefineInjector"]({
        factory: function AngularFireFunctionsModule_Factory(t) {
          return new (t || AngularFireFunctionsModule)();
        },
        providers: [AngularFireFunctions]
      });
      /*@__PURE__*/

      (function () {
        _angular_core__WEBPACK_IMPORTED_MODULE_0__["ɵsetClassMetadata"](AngularFireFunctionsModule, [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_0__["NgModule"],
          args: [{
            providers: [AngularFireFunctions]
          }]
        }], null, null);
      })();
      /**
       * @fileoverview added by tsickle
       * Generated from: public_api.ts
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */

      /**
       * @fileoverview added by tsickle
       * Generated from: angular-fire-functions.ts
       * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingRequire,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
       */
      //# sourceMappingURL=angular-fire-functions.js.map

      /***/

    },

    /***/
    "./node_modules/raw-loader/dist/cjs.js!./src/app/showclass/showclass.page.html":
    /*!*************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/showclass/showclass.page.html ***!
      \*************************************************************************************/

    /*! exports provided: default */

    /***/
    function node_modulesRawLoaderDistCjsJsSrcAppShowclassShowclassPageHtml(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n<ion-header>\n    <ion-toolbar color=\"dark\">\n        <ion-buttons slot=\"start\">\n            <ion-back-button defaultHref=\"ocr\"></ion-back-button>\n        </ion-buttons>\n        <ion-buttons>\n            <ion-back-button onclick=\"callCloudFunction()\"></ion-back-button>\n        </ion-buttons>\n\n        <ion-title>Results</ion-title>\n    </ion-toolbar>\n</ion-header>\n\n\n<ion-content>\n\n    <img [src]=\"'data:image/jpeg;base64,'+image\" class=\"picture\" />\n\n    <ion-list *ngIf=\"(feature == 'TEXT_DETECTION' || feature == 'DOCUMENT_TEXT_DETECTION') && result \">\n        <ion-item>\n            <ion-label>I think this image contains following text:</ion-label>\n        </ion-item>\n        <ion-item lines=\"none\">\n            <ion-label>Text </ion-label>{{result[0].description}}\n        </ion-item>\n    </ion-list>\n    <ion-list *ngIf=\"!result\">\n        <ion-item lines=\"none\">\n            <ion-label class=\"ion-text-center\">Didn't find any related data</ion-label>\n        </ion-item>\n    </ion-list>\n    <ion-list *ngIf=\"(feature == 'FACE_DETECTION') && (result[0].faceAnnotations)\">\n        <ion-item lines=\"none\">\n            <ion-label class=\"ion-text-wrap\">According to me, facial expressions in this picture are as follows:\n            </ion-label>\n        </ion-item>\n        <ion-item>\n            <ion-label>Anger Likelihood</ion-label>{{result[0].faceAnnotations[0].angerLikelihood}}\n        </ion-item>\n        <ion-item>\n            <ion-label>Blurred Likelihood</ion-label>{{result[0].faceAnnotations[0].blurredLikelihood}}\n        </ion-item>\n        <ion-item>\n            <ion-label>Headwear Likelihood</ion-label>{{result[0].faceAnnotations[0].headwearLikelihood}}\n        </ion-item>\n        <ion-item>\n            <ion-label>Joy Likelihood</ion-label>{{result[0].faceAnnotations[0].joyLikelihood}}\n        </ion-item>\n        <ion-item>\n            <ion-label>Sorrow Likelihood</ion-label>{{result[0].faceAnnotations[0].sorrowLikelihood}}\n        </ion-item>\n        <ion-item>\n            <ion-label>Surprise Likelihood</ion-label>{{result[0].faceAnnotations[0].surpriseLikelihood}}\n        </ion-item>\n        <ion-item>\n            <ion-label>Under Exposed Likelihood</ion-label>{{result[0].faceAnnotations[0].underExposedLikelihood}}\n        </ion-item>\n        <ion-item lines=\"none\">\n            <div class=\"itemSection\">I can say this with\n                <p style=\"font-weight: bold; font-size: 15px; padding-left:5px; padding-right:5px\">\n                    {{result[0].faceAnnotations[0].detectionConfidence * 100| number:'.2-2'}} %</p>confidence</div>\n        </ion-item>\n    </ion-list>\n    <ion-list *ngIf=\"(feature == 'FACE_DETECTION') && (!result[0].faceAnnotations)\">\n        <ion-item lines=\"none\">\n            <ion-label class=\"ion-text-center\">Didn't find any face</ion-label>\n        </ion-item>\n    </ion-list>\n\n    <ion-grid>\n        <ion-row *ngIf=\"feature != 'FACE_DETECTION'\">\n            <ion-col size=\"12\" *ngFor=\"let item of result\">\n                <ion-list *ngIf=\"feature == 'LABEL_DETECTION' && item.description\">\n                    <ion-item lines=\"none\" *ngIf=\"item.description == result[0].description\" class=\"ion-text-center\">\n                        <ion-label>You are looking at a / an</ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"item.description == result[0].description\" class=\"ion-text-center\">\n                        <ion-label>\n                            <div class=\"ion-text-uppercase\">\n                                <p style=\"font-weight: bold; font-size: 20px; color: black;\" absolute-drag>\n                                    {{item.description}}</p>\n                            </div>\n                        </ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"item.description == result[0].description\">\n                        <div class=\"itemSection\">I can say this with\n                            <p style=\"font-weight: bold; font-size: 15px; padding-left:5px; padding-right:5px\">\n                                {{item.score * 100| number:'.2-2'}} %</p>confidence</div>\n                    </ion-item>\n                    <ion-item lines=\"full\" *ngIf=\"result[1] && item.description == result[1].description\">\n                        <ion-label class=\"ion-text-center\">\n                            <div>\n                                <p style=\"font-weight: bold; font-size: 15px;\" absolute-drag>Here are some of my other\n                                    predictions:</p>\n                            </div>\n                        </ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"result[1] && item.description == result[1].description\">\n                    </ion-item>\n                    <ion-item *ngIf=\"item.description != result[0].description\">\n                        <ion-label>Label</ion-label>{{item.description}}\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"item.description != result[0].description\">\n                        <ion-label>Score</ion-label>{{item.score}}\n                    </ion-item>\n                </ion-list>\n\n                <ion-list *ngIf=\"feature == 'CROP_HINTS'\">\n                    <ion-item lines=\"none\" class=\"ion-text-wrap\">\n                        <ion-text>I think important crop fraction for this picture is :\n                            <b>{{item.importanceFraction}}</b></ion-text>\n                    </ion-item>\n                    <ion-item lines=\"none\">I can say this with\n                        <p style=\"font-weight: bold; font-size: 15px; padding-left:5px; padding-right:5px\">\n                            {{item.confidence * 100| number:'.2-2'}} %</p>confidence\n                    </ion-item>\n                </ion-list>\n\n\n\n                <ion-list *ngIf=\"feature == 'IMAGE_PROPERTIES'\">\n                    <ion-item lines=\"none\"\n                        *ngIf=\"item.color.red == result[0].color.red && item.color.green == result[0].color.green && item.color.blue == result[0].color.blue\"\n                        class=\"ion-text-center\">\n                        <ion-label>This image contain major color (RGB)</ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\"\n                        *ngIf=\"item.color.red == result[0].color.red && item.color.green == result[0].color.green && item.color.blue == result[0].color.blue\"\n                        class=\"ion-text-center\">\n                        <ion-label>\n                            <div>\n                                <p style=\"font-weight: bold; font-size: 20px; color: black;\" absolute-drag>\n                                    ({{item.color.red}},{{item.color.green}},{{item.color.blue}})</p>\n                            </div>\n                            <br />having Pixel fraction <b>{{item.pixelFraction | number:'.2-2'}}</b>\n                        </ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\"\n                        *ngIf=\"item.color.red == result[0].color.red && item.color.green == result[0].color.green && item.color.blue == result[0].color.blue\">\n                        <div class=\"itemSection\">I can say this with\n                            <p style=\"font-weight: bold; font-size: 15px; padding-left:5px; padding-right:5px\">\n                                {{item.score * 100| number:'.2-2'}} %</p>confidence</div>\n                    </ion-item>\n                    <ion-item lines=\"full\"\n                        *ngIf=\"result[1] && item.color.red == result[1].color.red && item.color.green == result[1].color.green && item.color.blue == result[1].color.blue\">\n                        <ion-label class=\"ion-text-center\">\n                            <div>\n                                <p style=\"font-weight: bold; font-size: 15px;\" absolute-drag>Here are some of my other\n                                    predictions:</p>\n                            </div>\n                        </ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\"\n                        *ngIf=\"result[1] && item.color.red == result[1].color.red && item.color.green == result[1].color.green && item.color.blue == result[1].color.blue\">\n                    </ion-item>\n                    <ion-item\n                        *ngIf=\"(item.color.red != result[0].color.red) && (item.color.green != result[0].color.green) && (item.color.blue != result[0].color.blue)\">\n                        <ion-label>Color(RGB)</ion-label>({{item.color.red}},{{item.color.green}},{{item.color.blue}})\n                    </ion-item>\n                    <ion-item lines=\"none\"\n                        *ngIf=\"(item.color.red != result[0].color.red) && (item.color.green != result[0].color.green) && (item.color.blue != result[0].color.blue)\">\n                        <ion-label>Score</ion-label>{{item.score}}\n                    </ion-item>\n                </ion-list>\n\n                <ion-list *ngIf=\"feature == 'SAFE_SEARCH_DETECTION'\">\n                    <ion-item lines=\"none\">\n                        <ion-label class=\"ion-text-wrap\">According to me, safe search detections in this picture are as\n                            follows:</ion-label>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label>Adult</ion-label>{{item.safeSearchAnnotation.adult}}\n                    </ion-item>\n                    <ion-item>\n                        <ion-label>Medical</ion-label>{{item.safeSearchAnnotation.medical}}\n                    </ion-item>\n                    <ion-item>\n                        <ion-label>Spoof</ion-label>{{item.safeSearchAnnotation.spoof}}\n                    </ion-item>\n                    <ion-item>\n                        <ion-label>Violence</ion-label>{{item.safeSearchAnnotation.violence}}\n                    </ion-item>\n                    <ion-item lines=\"none\">\n                        <ion-label>Racy</ion-label>{{item.safeSearchAnnotation.racy}}\n                    </ion-item>\n                </ion-list>\n\n\n                <ion-list *ngIf=\"feature == 'OBJECT_LOCALIZATION' && item.name\">\n                    <ion-item lines=\"none\" *ngIf=\"item.name == result[0].name\">\n                        <ion-label class=\"ion-text-wrap\">According to me, Objects present in this picture are as\n                            follows:</ion-label>\n                    </ion-item>\n                    <ion-item>\n                        <ion-label>Object</ion-label>{{item.name}}\n                    </ion-item>\n                    <ion-item lines=\"none\">\n                        <ion-label>Score</ion-label>{{item.score}}\n                    </ion-item>\n                </ion-list>\n\n\n                <ion-list *ngIf=\"feature == 'LANDMARK_DETECTION' && item.description\">\n                    <ion-item lines=\"none\" *ngIf=\"item.description == result[0].description\" class=\"ion-text-center\">\n                        <ion-label>You are looking at a / an</ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"item.description == result[0].description\" class=\"ion-text-center\">\n                        <ion-label>\n                            <div class=\"ion-text-uppercase\">\n                                <p style=\"font-weight: bold; font-size: 20px; color: black;\" absolute-drag>\n                                    {{item.description}}</p>\n                            </div>\n                        </ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"item.description == result[0].description\">\n                        <div class=\"itemSection\">I can say this with\n                            <p style=\"font-weight: bold; font-size: 15px; padding-left:5px; padding-right:5px\">\n                                {{item.score * 100| number:'.2-2'}} %</p>confidence</div>\n                    </ion-item>\n                    <ion-item lines=\"full\" *ngIf=\"result[1] && item.description == result[1].description\">\n                        <ion-label class=\"ion-text-center\">\n                            <div>\n                                <p style=\"font-weight: bold; font-size: 15px;\" absolute-drag>Here are some of my other\n                                    predictions:</p>\n                            </div>\n                        </ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"result[1] && item.description == result[1].description\">\n                    </ion-item>\n                    <ion-item *ngIf=\"item.description != result[0].description\">\n                        <ion-label>Label</ion-label>{{item.description}}\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"item.description != result[0].description\">\n                        <ion-label>Score</ion-label>{{item.score}}\n                    </ion-item>\n                </ion-list>\n\n\n                <ion-list *ngIf=\"feature == 'LOGO_DETECTION' && item.description\">\n                    <ion-item lines=\"none\" *ngIf=\"item.description == result[0].description\" class=\"ion-text-center\">\n                        <ion-label>You are looking at Logo of </ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"item.description == result[0].description\" class=\"ion-text-center\">\n                        <ion-label>\n                            <div class=\"ion-text-uppercase\">\n                                <p style=\"font-weight: bold; font-size: 20px; color: black;\" absolute-drag>\n                                    {{item.description}}</p>\n                            </div>\n                        </ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"item.description == result[0].description\">\n                        <div class=\"itemSection\">I can say this with\n                            <p style=\"font-weight: bold; font-size: 15px; padding-left:5px; padding-right:5px\">\n                                {{item.score * 100| number:'.2-2'}} %</p>confidence</div>\n                    </ion-item>\n                    <ion-item lines=\"full\" *ngIf=\"result[1] && item.description == result[1].description\">\n                        <ion-label class=\"ion-text-center\">\n                            <div>\n                                <p style=\"font-weight: bold; font-size: 15px;\" absolute-drag>Here are some of my other\n                                    predictions:</p>\n                            </div>\n                        </ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"result[1] && item.description == result[1].description\">\n                    </ion-item>\n                    <ion-item *ngIf=\"item.description != result[0].description\">\n                        <ion-label>Label</ion-label>{{item.description}}\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"item.description != result[0].description\">\n                        <ion-label>Score</ion-label>{{item.score}}\n                    </ion-item>\n                </ion-list>\n\n\n                <ion-list *ngIf=\"feature == 'WEB_DETECTION' && item.description\">\n                    <ion-item lines=\"none\" *ngIf=\"item.description == result[0].description\" class=\"ion-text-center\">\n                        <ion-label>You are looking at </ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"item.description == result[0].description\" class=\"ion-text-center\">\n                        <ion-label>\n                            <div class=\"ion-text-uppercase\">\n                                <p style=\"font-weight: bold; font-size: 20px; color: black;\" absolute-drag>\n                                    {{item.description}}</p>\n                            </div>\n                        </ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"item.description == result[0].description\">\n                        <div class=\"itemSection\">I can say this with\n                            <p style=\"font-weight: bold; font-size: 15px; padding-left:5px; padding-right:5px\">\n                                {{item.score * 100| number:'.2-2'}} %</p>confidence</div>\n                    </ion-item>\n                    <ion-item lines=\"full\" *ngIf=\"result[1] && item.description == result[1].description\">\n                        <ion-label class=\"ion-text-center\">\n                            <div>\n                                <p style=\"font-weight: bold; font-size: 15px;\" absolute-drag>Here are some of my other\n                                    predictions:</p>\n                            </div>\n                        </ion-label>\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"result[1] && item.description == result[1].description\">\n                    </ion-item>\n                    <ion-item *ngIf=\"item.description != result[0].description\">\n                        <ion-label>Label</ion-label>{{item.description}}\n                    </ion-item>\n                    <ion-item lines=\"none\" *ngIf=\"item.description != result[0].description\">\n                        <ion-label>Score</ion-label>{{item.score}}\n                    </ion-item>\n                </ion-list>\n            </ion-col>\n        </ion-row>\n    </ion-grid>\n</ion-content>";
      /***/
    },

    /***/
    "./src/app/showclass/showclass.module.ts":
    /*!***********************************************!*\
      !*** ./src/app/showclass/showclass.module.ts ***!
      \***********************************************/

    /*! exports provided: ShowclassPageModule */

    /***/
    function srcAppShowclassShowclassModuleTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ShowclassPageModule", function () {
        return ShowclassPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! @ionic/angular */
      "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
      /* harmony import */


      var _showclass_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./showclass.page */
      "./src/app/showclass/showclass.page.ts");

      var routes = [{
        path: '',
        component: _showclass_page__WEBPACK_IMPORTED_MODULE_6__["ShowclassPage"]
      }];

      var ShowclassPageModule = function ShowclassPageModule() {
        _classCallCheck(this, ShowclassPageModule);
      };

      ShowclassPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)],
        declarations: [_showclass_page__WEBPACK_IMPORTED_MODULE_6__["ShowclassPage"]]
      })], ShowclassPageModule);
      /***/
    },

    /***/
    "./src/app/showclass/showclass.page.scss":
    /*!***********************************************!*\
      !*** ./src/app/showclass/showclass.page.scss ***!
      \***********************************************/

    /*! exports provided: default */

    /***/
    function srcAppShowclassShowclassPageScss(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "img {\n  height: 70vh !important;\n  width: auto !important;\n  margin-left: auto !important;\n  margin-right: auto !important;\n  margin-bottom: auto !important;\n  margin-top: 10px;\n  display: block !important;\n  border: 1px solid #000;\n  padding: 5px;\n  border-radius: 4px;\n}\n\n.itemSection {\n  display: flex;\n  justify-content: center;\n  align-items: center;\n  width: 100%;\n}\n\nion-content {\n  background: #f0efef;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvc2hvd2NsYXNzL3Nob3djbGFzcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBRUE7RUFDRSx1QkFBQTtFQUNBLHNCQUFBO0VBQ0EsNEJBQUE7RUFDQSw2QkFBQTtFQUNBLDhCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx5QkFBQTtFQUNBLHNCQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0FBREY7O0FBSUE7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7RUFDQSxtQkFBQTtFQUNBLFdBQUE7QUFERjs7QUFHQTtFQUNFLG1CQUFBO0FBQUYiLCJmaWxlIjoic3JjL2FwcC9zaG93Y2xhc3Mvc2hvd2NsYXNzLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIlxuXG5pbWcge1xuICBoZWlnaHQ6IDcwdmggIWltcG9ydGFudDtcbiAgd2lkdGg6IGF1dG8gIWltcG9ydGFudDtcbiAgbWFyZ2luLWxlZnQ6IGF1dG8gIWltcG9ydGFudDtcbiAgbWFyZ2luLXJpZ2h0OiBhdXRvICFpbXBvcnRhbnQ7XG4gIG1hcmdpbi1ib3R0b206IGF1dG8gIWltcG9ydGFudDtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgZGlzcGxheTogYmxvY2sgIWltcG9ydGFudDtcbiAgYm9yZGVyOiAxcHggc29saWQgIzAwMDtcbiAgcGFkZGluZzogNXB4O1xuICBib3JkZXItcmFkaXVzOiA0cHg7XG59XG5cbi5pdGVtU2VjdGlvbiB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICB3aWR0aDogMTAwJTtcbn1cbmlvbi1jb250ZW50IHtcbiAgYmFja2dyb3VuZDogI2YwZWZlZjtcbn1cbiJdfQ== */";
      /***/
    },

    /***/
    "./src/app/showclass/showclass.page.ts":
    /*!*********************************************!*\
      !*** ./src/app/showclass/showclass.page.ts ***!
      \*********************************************/

    /*! exports provided: ShowclassPage */

    /***/
    function srcAppShowclassShowclassPageTs(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ShowclassPage", function () {
        return ShowclassPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "./node_modules/tslib/tslib.es6.js");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
      /* harmony import */


      var _angular_fire_functions__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/fire/functions */
      "./node_modules/@angular/fire/__ivy_ngcc__/fesm2015/angular-fire-functions.js");
      /* harmony import */


      var _firebase_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! ../firebase.service */
      "./src/app/firebase.service.ts"); //import { data } from 'jquery';


      var ShowclassPage = /*#__PURE__*/function () {
        function ShowclassPage(route, router, functions, firebaseService) {
          _classCallCheck(this, ShowclassPage);

          this.route = route;
          this.router = router;
          this.functions = functions;
          this.firebaseService = firebaseService;
        }

        _createClass(ShowclassPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {
            var _this = this;

            this.route.queryParams.subscribe(function (params) {
              if (params && params.special && params.result && params.feature) {
                _this.image = JSON.parse(params.special);
                _this.result = JSON.parse(params.result);
                _this.feature = JSON.parse(params.feature);
              }

              switch (_this.feature) {
                case 'TEXT_DETECTION':
                  {
                    _this.result = _this.result.responses[0].textAnnotations;

                    _this.callCloudFunction(_this.result);

                    break;
                  }

                default:
                  {
                    _this.result = _this.result.responses[0].labelAnnotations;
                  }
              }

              console.log(_this.result);
            });
          }
        }, {
          key: "callCloudFunction",
          value: function callCloudFunction(data) {
            var _this2 = this;

            // Use the function name from Firebase
            var callable = this.functions.httpsCallable('myUppercaseFunction'); // Create an Observable and pass any data you want to the function

            var obs = callable({
              coolMsg: data
            });
            obs.subscribe(function (res) {
              return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
                return regeneratorRuntime.wrap(function _callee$(_context) {
                  while (1) {
                    switch (_context.prev = _context.next) {
                      case 0:
                        _context.next = 2;
                        return this.firebaseService.createOTask({
                          ocr: res.msg
                        });

                      case 2:
                        this.router.navigate(["/tabs/ocr"]);

                      case 3:
                      case "end":
                        return _context.stop();
                    }
                  }
                }, _callee, this);
              }));
            });
          }
        }]);

        return ShowclassPage;
      }();

      ShowclassPage.ctorParameters = function () {
        return [{
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
        }, {
          type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
        }, {
          type: _angular_fire_functions__WEBPACK_IMPORTED_MODULE_3__["AngularFireFunctions"]
        }, {
          type: _firebase_service__WEBPACK_IMPORTED_MODULE_4__["FirebaseService"]
        }];
      };

      ShowclassPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-showclass',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! raw-loader!./showclass.page.html */
        "./node_modules/raw-loader/dist/cjs.js!./src/app/showclass/showclass.page.html"))["default"],
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
        /*! ./showclass.page.scss */
        "./src/app/showclass/showclass.page.scss"))["default"]]
      })], ShowclassPage);
      /***/
    }
  }]);
})();
//# sourceMappingURL=showclass-showclass-module-es5.js.map